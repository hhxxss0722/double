#coding:utf-8
for i in range(0,6):
	print(i)
	
for i in range(6,12):
	print("*",i)