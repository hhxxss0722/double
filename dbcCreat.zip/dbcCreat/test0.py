import os
import xlrd
import win32ui


dlg = win32ui.CreateFileDialog(1)
dlg.SetOFNInitialDir('C:\1work\T-box\Tools\dbc生成工具')
dlg.DoModal()

filename = dlg.GetPathName()
my_path = os.path.abspath('main.py')
print(my_path)
# print(os.path.split(my_path)[0])
# print(os.path.basename(my_path))
print(os.path.dirname(my_path))
base_path = os.path.dirname(my_path)
print(os.path.exists(base_path+'/pre_dbc'))
data = xlrd.open_workbook(filename)
table = data.sheet_by_index(0)
print(table.row_values(23)[9])
print(table.ncols)

# newfile = open(os.path.dirname(my_path)+'\\dbc.txt','w')
# newfile.write('1231231')
# newfile.close()

