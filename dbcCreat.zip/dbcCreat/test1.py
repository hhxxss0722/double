print(0x18F52524)
print(str( (int('0x18F52524',16) & 0x1fffffff) ))

# import  getData
#
# print(getData.formula_split('0.1*x+10'))
# print(getData.formula_split('x+20'))
# print(getData.formula_split('x'))
# print(getData.formula_split('x-10'))
# print(getData.formula_split('0.2*x-10'))
# print(getData.formula_split('0.2*x'))
# print(getData.formula_split('x+sfdf'))
#
# content_title = ['Tbox统一信号名称','报文名称','信号起始位','信号长度(bit)','物理值范围','单位','计算公式','车厂状态类信号']
# j = [1,4,5,6,7,8,9,10]
# s = zip(content_title,j)
