import tkinter as tk

root = tk.Tk()

label = tk.Label(root, text="Hello World", padx=10, pady=10)
label.pack()

root.mainloop()
