from PyQt5.QtWidgets import (QWidget, QToolTip, QPushButton, QApplication, QMessageBox, QDesktopWidget)
from PyQt5.QtGui import QIcon, QFont
import PyQt5.QtGui
import PyQt5.QtCore as Qt
import sys

from PyQt5.QtWidgets import (QWidget, QLCDNumber, QSlider,
                             QVBoxLayout, QApplication)


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        self.centralwidget = PyQt5.QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.tableWidget = PyQt5.QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setGeometry(PyQt5.QtCore.QRect(60, 80, 601, 192))
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(6)

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle("MainWindow")
        item = self.tableWidget.verticalHeaderItem(0)
        # item.setText("MainWindow")
        item = self.tableWidget.horizontalHeaderItem(0)
        # item.setText("MainWindow")
        item = self.tableWidget.horizontalHeaderItem(1)
        # item.setText("MainWindow")


# class myprog(Ui_MainWindow):
#     def __init__(self, dialog):
#         Ui_MainWindow.__init__(self)
#         self.setupUi(dialog)
#         self.retranslateUi(dialog)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    dialog = PyQt5.QtWidgets.QMainWindow()

    coll=Ui_MainWindow().setupUi(dialog)
    # tbox = myprog(dialog)
    dialog.show()

    sys.exit(app.exec_())